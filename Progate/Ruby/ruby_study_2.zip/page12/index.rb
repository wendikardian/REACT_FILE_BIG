exams = [
  {subject: "Math", score: 80},
  {subject: "Science", score: 55}
]

# Print value of the element with the symbol :score at index 1
puts exams[1][:score]
