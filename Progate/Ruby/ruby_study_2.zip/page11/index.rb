# Assign a list of hashes into the exams variable
exams = [
  {subject: "Math", score: 80},
  {subject: "Science", score: 55}
  ]

# Print the element at index 1
puts exams[1]

