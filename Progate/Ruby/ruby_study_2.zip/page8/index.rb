# Rewrite the below hash using the shorthand syntax
exam = {subject: "Math", score: 80}

puts "#{exam[:subject]} score is #{exam[:score]}"
