# Assign a list of languages to the languages variable
languages = ["Japanese", "English", "Spanish"]


# Print the languages variable

puts languages
