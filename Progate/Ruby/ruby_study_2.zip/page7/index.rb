# Rewrite the hash below using symbols
exam = {:subject => "Math", :score => 80}

# Print the value of the element with the symbol :score
puts exam[:score]
