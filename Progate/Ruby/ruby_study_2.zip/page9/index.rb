exam = {subject: "Math", score: 80}

# Print the value with the symbol :grade
puts exam[:grade]

# Print nil
puts nil

