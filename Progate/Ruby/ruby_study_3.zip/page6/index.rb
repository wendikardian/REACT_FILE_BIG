# Add price as the second parameter
def print_info(item, price)
  puts "Welcome to Ninja Electronics!"
  puts "#{item}s are on sale today! Only $#{price} each!"
end

# Call the print_info method
print_info("Flash Drive", 12)

