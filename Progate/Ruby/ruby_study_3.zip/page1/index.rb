def introduce
  puts "Hello"
  puts "I am Ken the Ninja"
  # Print "I am 14 years old"
  puts "I am 14 years old"
  
end

puts "-----Self Intro-----"
# Call the introduce method
puts introduce
