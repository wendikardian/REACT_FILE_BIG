# Define the print_info method
def print_info
  puts "Welcome to Ninja Electronics!"
  puts "Headphones are on sale today!"
end

# Call the print_info method
print_info
