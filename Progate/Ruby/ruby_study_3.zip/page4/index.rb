# Define the print_info method
def print_info(item)
  puts "Welcome to Ninja Electronics!"
  puts "#{item}s are on sale today!"
end

# Call the print_info method with the argument "Headphone"
print_info("Headphone")

# Call the print_info method with the argument "TV"
print_info("TV")
