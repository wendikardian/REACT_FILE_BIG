require "./menu"

class Food < Menu
  # Add the calorie instance variable
  attr_accessor :calorie
end
