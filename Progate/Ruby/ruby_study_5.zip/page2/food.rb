# Import menu.rb using require
require './menu'

# Define the Food class that inherits from the Menu class
class Food < Menu
end

