# Import menu.rb using require
require './menu'

# Define the Drink class that inherits from the Menu class
class Drink < Menu
end

