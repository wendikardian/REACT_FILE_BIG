# Import the Date class using require
require "date"

# Assign an instance of Date to the birthday variable
birthday = Date.new(2002, 9, 14)

# Print the birthday variable
puts birthday

# Print the return value of the sunday? instance method of the birthday variable
puts birthday.sunday?
