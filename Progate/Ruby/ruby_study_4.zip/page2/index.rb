# Define the Menu class
class Menu
end
