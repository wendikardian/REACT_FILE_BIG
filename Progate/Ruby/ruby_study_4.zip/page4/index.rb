class Menu
  attr_accessor :name
  attr_accessor :price
end

# Assign an instance of Menu to the menu1 variable
menu1 = Menu.new