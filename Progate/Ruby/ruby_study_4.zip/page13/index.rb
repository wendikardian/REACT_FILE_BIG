# Import menu.rb
require './menu'
# Move the Menu class to menu.rb


# Do not move this code
menu1 = Menu.new(name: "Sushi", price: 10)

puts menu1.info
