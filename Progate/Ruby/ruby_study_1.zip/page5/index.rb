# Concatenate "I am " and "Ken the Ninja", and print it
puts "I am " + "Ken the Ninja"

# Concatenate "38" and "19", and print it
puts "38" + "19"
