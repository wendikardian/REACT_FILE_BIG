length = 9
width = 8
puts width
puts length * width
puts "----"

# Update the width variable with 13
width = 13

puts width
puts length * width
