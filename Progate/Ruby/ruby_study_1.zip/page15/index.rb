score = 60

# Add an else statement to print "You can do better!"
if score > 80
  puts "Great job!"
else
  puts "You can do better!"
end
