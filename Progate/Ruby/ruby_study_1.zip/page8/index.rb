# Assign " is an awesome programming language" to the text variable
text = " is an awesome programming language"

# Concatenate the following strings with the text variable and print the result
puts "Ruby" + text
puts "Python" + text
puts "Java" + text