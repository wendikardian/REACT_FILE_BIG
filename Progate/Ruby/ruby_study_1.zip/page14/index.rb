score = 100

# If the score is 100, print "Great job!"
if(score == 100)
  puts "Great job!"
end
# If the score is not 100, print "You can do better!"
if(score != 100)
  puts "You can do better!"
end

