# Print the result of 13 times 9
puts 13*9

# Print the result of 32 divided by 8
puts 32/8

# Print the remainder of 18 divided by 5
puts 18%5
