score = 96

# When score is greater or equal to 95 and less than or equal 99,
# print the message "Good job! Almost perfect."
if score >= 95 && score <= 99
  puts "Good job! Almost perfect."
end
