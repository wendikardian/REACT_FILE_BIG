# Print 37 as an integer
puts 37

# Print the sum of 2 and 9
puts 2 + 9

# Print "2 + 9" as a string
puts "2 + 9"

