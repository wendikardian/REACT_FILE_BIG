-- get the name and number of items for users who have purchased 10 items or more
select users.id, users.name, count(*) as "number"
from users 
join sales_records
on users.id = sales_records.user_id
group by users.id
having count(*) >= 10
;