-- get the user id and name of unique users who purchased "sandals"
select DISTINCT users.id, users.name
from users
join sales_records
on users.id = sales_records.user_id
join items
on sales_records.item_id = items.id
where items.name = "sandals"
;