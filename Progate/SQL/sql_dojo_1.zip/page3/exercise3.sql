-- get all rows that contain the string "shirt"
SELECT *
from items
where name like "%shirt%";