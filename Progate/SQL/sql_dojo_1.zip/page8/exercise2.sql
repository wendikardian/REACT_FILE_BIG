-- get the total sales and the date for each day
select purchased_at, sum(items.price) as "total sales"
from sales_records
join items
on sales_records.item_id = items.id
group by purchased_at