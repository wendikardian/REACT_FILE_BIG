select items.id, items.name, price * count(*) as "sales total"
from sales_records
join items
on sales_records.item_id = items.id
group by items.id, items.name, items.price
having price * count(*) > (
select price * count(*)
FROM sales_records            
JOIN items            
ON sales_records.item_id = items.id            
WHERE items.name = "grey hoodie"
);