-- get the specified data for men's, women's, and gender neutral products
select items.gender, sum(items.price)
from items
join sales_records
on items.id = sales_records.item_id
group by items.gender
;