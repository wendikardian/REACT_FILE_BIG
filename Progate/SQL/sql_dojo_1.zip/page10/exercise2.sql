-- get the specified data for the top 5 products with the highest sales
select items.id, items.name, count(*) * price as "sales total"
from sales_records
join items
on  sales_records.item_id = items.id 
group by items.name, items.id, items.price
order by count(*) * price desc limit 5;