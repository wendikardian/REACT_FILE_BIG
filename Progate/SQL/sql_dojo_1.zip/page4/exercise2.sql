-- get the average profit value for all products
select avg(price - cost)
from items;