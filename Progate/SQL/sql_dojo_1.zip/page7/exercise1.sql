-- get the name and number sold for the top 5 most-sold items

select sales_records.item_id, items.name, count(sales_records.item_id)
from sales_records
join items
on  sales_records.item_id = items.id
group by sales_records.item_id
order by count(*) desc limit 5;