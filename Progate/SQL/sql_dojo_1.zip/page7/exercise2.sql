-- get the total sales and total profit for the entire site
select sum(price) as "total sales", sum(price - cost) as "total profit"
from items 
join sales_records 
on items.id = sales_records.item_id
;