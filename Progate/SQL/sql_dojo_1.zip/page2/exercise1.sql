-- get the average age of all users
SELECT AVG(users.age)
from users;