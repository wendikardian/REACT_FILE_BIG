SELECT *
FROM players
WHERE goals >14 ;
