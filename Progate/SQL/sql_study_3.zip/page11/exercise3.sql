SELECT countries.name as "country name", AVG(players.goals) as "average score"
FROM players 
JOIN countries
ON players.country_id = countries.id
GROUP BY countries.name;
