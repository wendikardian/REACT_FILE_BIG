SELECT name as "player name", height as "height"
FROM players 
WHERE height > (
SELECT AVG(height) 
FROM players
);