-- add data to the students table
insert into students (name, course) values ("Kate", "Java");

-- do not delete the following query
select * from students;
