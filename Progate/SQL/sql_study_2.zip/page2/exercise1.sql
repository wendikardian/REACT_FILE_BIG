-- get the data from the price column with sales tax included by adding to the statement below

SELECT name, price,  price*1.09
FROM purchases;