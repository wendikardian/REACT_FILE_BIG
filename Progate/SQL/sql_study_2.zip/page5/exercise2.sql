-- get the total number of rows in the purchases table 

SELECT COUNT(*)
FROM purchases;