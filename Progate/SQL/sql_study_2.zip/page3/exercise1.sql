-- get the sum total of the price column 

SELECT SUM(price) as total
FROM purchases;