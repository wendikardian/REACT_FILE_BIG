-- get the lowest value in the price column 

SELECT MIN(price)
FROM purchases;