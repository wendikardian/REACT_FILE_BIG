-- run the code to see the rows of the character_name column without duplicates removed

SELECT  character_name
FROM purchases;