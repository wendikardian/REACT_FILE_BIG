-- get the total amount of money spent for each purchased_at group

SELECT sum(price),purchased_at
FROM purchases GROUP BY purchased_at

;