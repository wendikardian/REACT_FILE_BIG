class Main {
  public static void main(String[] args) {
    // Concatenate "Hello" and "World", and print it
    System.out.println("Hello " + "World");
    
    // Concatenate "38" and "19", and print it
    System.out.println("38"+"19");
    
    // Add 38 and 19, and print it
    System.out.println(38+19);
    
  }
}

