class Main {
  public static void main(String[] args) {
    int number1 = 3;
    
    // Declare the number2 variable of type int, and assign 7 to it.
    int number2 = 7;
    
    // Print the result of number1 * number2
    System.out.println(number1*number2);
    
    // Assign "Let's learn programming" to the text variable
    String text = "Let's learn programming";
    System.out.println(text + " using Progate");
    
    // Concatenate the text variable and the given string, and print the result 
    
    
  }
}
