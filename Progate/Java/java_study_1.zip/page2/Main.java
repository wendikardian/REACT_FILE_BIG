class Main {
  public static void main(String[] args) {
    
    // This line should be a comment
    
    // Print "Hello Java"
    System.out.println("Hello Java");
    
  }
}

