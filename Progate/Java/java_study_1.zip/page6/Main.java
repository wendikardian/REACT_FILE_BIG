class Main {
  public static void main(String[] args) {
    // Declare the number variable of type int
    int number;
    number = 3;
    System.out.println(number);
    String name;
    name = "Bob";
    System.out.println(name);
    
    // Assign 3 to the number variable
    
    
    // Print the number variable
    
    
    // Declare the name variable of type String
    
    
    // Assign "Bob" to the name variable
    
    
    // Print the name variable
    
    
    
  }
}
