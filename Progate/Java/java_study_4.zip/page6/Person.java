class Person {
  public String name;

  public void hello() {
    // Use this to output "Hello, my name is ____."
    System.out.println("Hello, my name is" + this.name +".");
  }
}
