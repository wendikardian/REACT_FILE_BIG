class Main {
  public static void main(String[] args) {
    Person person1 = new Person();
    // Call the hello method using the person1 instance
    person1.hello();
    
    Person person2 = new Person();
    // Call the hello method using the person2 instance
    person2.hello();
    
  }
}
