class Person {
  // Define the hello instance method
  public void hello(){
    System.out.println("Hello");
  }
  
}