class Main {
  public static void main(String[] args) {
    Person person1 = new Person("Kate Jones");
    Person person2 = new Person("John Christopher Smith");

    person1.hello();
    person2.hello();
  }
}
