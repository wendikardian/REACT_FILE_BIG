class Person {
  // Declare the name instance field
  public String name;

  public void hello() {
    System.out.println("Hello");
  }
}
