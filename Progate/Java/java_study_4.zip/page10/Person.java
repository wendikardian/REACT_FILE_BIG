class Person {
  // Declare the instance fields
  public String firstName;
  public String lastName;
  public int age;
  public double height;
  public double weight;
  
  Person(String firstName, String lastName, int age, double height, double weight){
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.height = height;
    this.weight = weight;
  }

  // Define the constructor to set the instance fields
  
  
}
