class Main {
  public static void main(String[] args) {
    // Print true
    System.out.println(true);
    
    // Print false
    System.out.println(false);
    
    // Compare the values using == and print the result
    System.out.println(12/4 == 3);
    
    // Compare the values using != and print the result
    System.out.println(12/4 != 3);
    
    // Declare the bool variable type of boolean, and assign the result of 3 * 9 == 27 to it
    
    
    // Print the value of the bool variable
    boolean bool = 3*9 ==27;
    System.out.println(bool);
    
  }
}
