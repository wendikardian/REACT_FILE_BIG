// Inherit the Vehicle class
class Car extends Vehicle {
  // Move the code below to the Vehicle class
 
}