// Inherit the Vehicle class
class Bicycle extends Vehicle{
  // Move the code below to the Vehicle class
  
}