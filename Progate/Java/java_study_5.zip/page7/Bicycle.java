class Bicycle extends Vehicle {
  // Define the constructor for the Bicycle class
  // Call the constructor of the superclass using super()
  Bicycle(String name, String color){
    super(name, color);
  }
  
}
