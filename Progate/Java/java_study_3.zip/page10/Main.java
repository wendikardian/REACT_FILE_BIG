public class Main {
  public static void main(String[] args) {
    // Rewrite the calls to the printData and fullName methods
    Person.printData(Person.fullName("Kate", "Jones"), 27, 1.6, 50.0);
    Person.printData(Person.fullName("John", "Christopher", "Smith"), 65, 1.75, 80.0);
  }
  
  // Move all of the methods below to the Person class
  
}
