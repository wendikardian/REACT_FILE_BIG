class Car{
  private String name ;
  private String color;
  private int distance;
  private int fuel;
  
  Car (String name, String color, int distance, int fuel){
    this.name = name;
    this.color = color;
    this.distance = distance;
    this.fuel = fuel;
  }
  
  public String getName(){
    return this.name;
  }
  
  public String getColor(){
    return this.color;
  }
  
  public int getDistance(){
    return this.distance;
  }
  
  public int getFuel(){
    return this.fuel;
  }
  
  public void run(int distance){
    
    System.out.println("Moving "+ distance +  "km ...");
    int total = distance + this.distance;
    if(this.fuel > total){
      System.out.println("Distance: " +  total + "km");
      int rest = this.fuel - total;
      System.out.println("Fuel: " +  rest + "L");
    }else{
      System.out.println("Not enough fuel");
      System.out.println("Distance: 0km");
      System.out.println("Fuel: " + this.fuel + "L" );
    }
  }
}