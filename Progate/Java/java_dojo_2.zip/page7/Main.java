import java.util.Scanner;
class Main {
  public static void main(String[] args) {
   Bicycle bicycle1 = new Bicycle("Bianchi", "Green", 0);
   System.out.println("Name: " + bicycle1.getName()) ;
   System.out.println("Color: " + bicycle1.getColor()) ;
   System.out.println("Distance: " + bicycle1.getDistance() + "km") ;
   System.out.println("-----------------");
   Scanner scanner = new Scanner(System.in);
   System.out.println("Enter distance to move: ");
   int move = scanner.nextInt();
   bicycle1.run(move);
   System.out.println("=================");
   Car car1 = new Car("Ferrari", "Red", 0);
   System.out.println("【Car Info】");
   System.out.println("Name: " + car1.getName()) ;
   System.out.println("Color: " + car1.getColor()) ;
   System.out.println("Distance: " + car1.getDistance() + "km") ;
  }
}