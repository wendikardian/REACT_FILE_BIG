class Main {
  public static void main(String[] args) {
   Bicycle bicycle1 = new Bicycle("Bianchi", "Green");
   System.out.println("Name: " + bicycle1.getName()) ;
   System.out.println("Color: " + bicycle1.getColor()) ;
  }
}