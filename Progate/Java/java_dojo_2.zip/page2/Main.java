class Main {
  public static void main(String[] args) {
   Bicycle bicycle1 = new Bicycle("Bianchi");
   System.out.println("Name: " + bicycle1.getName()) ;
  }
}