class Main {
  public static void main(String[] args) {
   Bicycle bicycle1 = new Bicycle("Bianchi", "Green", 0);
   System.out.println("Name: " + bicycle1.getName()) ;
   System.out.println("Color: " + bicycle1.getColor()) ;
   System.out.println("Distance: " + bicycle1.getDistance() + "km") ;
   System.out.println("-----------------");
   bicycle1.run(10);
  }
}