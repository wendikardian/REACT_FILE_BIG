import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Number of people: ");
    int number = scanner.nextInt();
    int i = 1;
    while( i <= number){
        System.out.println("Person number "+ i);
        System.out.println("First name: ");
        String firstName = scanner.next();
        System.out.println("My name is "+ firstName + ".");
        System.out.println("Last name: ");
        String lastName =scanner.next();
        System.out.println("Age: ");
        int age = scanner.nextInt();
        System.out.println("Height (m): ");
        double height = scanner.nextDouble();
        System.out.println("Weight (kg): ");
        double weight = scanner.nextDouble();
        String name = firstName + " " + lastName;
        Person.info(name, age, height, weight);
        i++;
    }
    
    
  }
}
