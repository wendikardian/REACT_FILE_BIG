import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("First name: ");
    String firstName = scanner.next();
    System.out.println("My name is "+ firstName + ".");
  }
}
