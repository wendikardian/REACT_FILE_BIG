import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("First name: ");
    String firstName = scanner.next();
    System.out.println("My name is "+ firstName + ".");
    System.out.println("Last name: ");
    String lastName =scanner.next();
    System.out.println("Age: ");
    int age = scanner.nextInt();
    System.out.println("Height (m): ");
    double height = scanner.nextDouble();
    System.out.println("Weight (kg): ");
    double weight = scanner.nextDouble();
    System.out.println("My name is "+ firstName + " " + lastName + ".");
    System.out.println("I am "+ age +" years old.");
    if(age >= 18){
      System.out.println("I am an adult.");
    }else{
      System.out.println("I am not an adult.");
    }
    System.out.println("I am "+height+"m tall.");
    System.out.println("I weigh "+weight+"kg.");
    
  }
}
