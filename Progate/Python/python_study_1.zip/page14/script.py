x = 20
# if x ranges from 10 to 30 inclusive, print 'x ranges from 10 to 30'
if x>=10 and x<=30:
    print('x ranges from 10 to 30')


y = 60
# if y is less than 10 or greater than 30, print 'y is less than 10 or greater than 30'
if y< 10 or y>30:
    print('y is less than 10 or greater than 30')


z = 55
# if z is not equal to 77, print 'z is not 77'
if  not z == 77:
    print('z is not 77')

