# Assign 'Bob' to the my_name variable
my_name = "Bob"

# Print 'I am Bob' by combining the my_name variable and a string
print("I am "+ my_name)
