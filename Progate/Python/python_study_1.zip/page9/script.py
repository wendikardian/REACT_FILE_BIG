age = 24
# Print 'I am 24 years old' using the age variable
print('I am '+str(age)+ " years old")

count = '5'
# Convert the count variable to an integer data type, add 1 to it, and print it
print( int(count) + 1)
