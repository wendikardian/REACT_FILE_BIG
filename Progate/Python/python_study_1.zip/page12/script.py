money = 2
apple_price = 4

if money >= apple_price:
    print('You can buy an apple')
# When the condition above is False, print 'You do not have enough money'
else:
    print("You do not have enough money")

