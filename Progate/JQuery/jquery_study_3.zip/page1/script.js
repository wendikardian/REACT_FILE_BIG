$(function() {
  // Create a click event for the #hide-btn element
  $('#hide-btn').click(function(){
    $('.slide').eq(1).fadeOut();
  })
  
});