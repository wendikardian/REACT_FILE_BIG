$(function() {
  $('#second-btn').click(function() {
    // Remove the active class from the .active element
    $('.active').removeClass('active');
    $('.slide').eq(1).addClass('active');
    
    // Add the active class to the 2nd .slide element
    
    
  });
});
