$(function() {

  // Signup modal

  $('.signup-show').click(function() {
    $('#signup-modal').fadeIn();
  });

  $('#close-modal').click(function() {
    $('#signup-modal').fadeOut();
  });

  // Language list

  $('.lesson').hover(
    function() {
      $(this).find('.text-contents').addClass('text-active');
    },
    function() {
      $(this).find('.text-contents').removeClass('text-active');
    }
  );
  
  $('.faq-list-item').click(function(){
    var $answer = $(this).find('.answer');
    if($answer.hasClass('showup')){
      $answer.slideUp();
      $answer.removeClass('showup');
      $(this).find('span').text('+');
    }else{
      $answer.slideDown();
      $answer.addClass('showup');
      $(this).find('span').text('-');
    }
  })
  

});
