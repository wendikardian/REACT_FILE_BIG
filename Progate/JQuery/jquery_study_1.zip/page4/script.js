$(function() {
  // Use the slideUp() method to hide the element with the id "title"
  $('#title').slideUp();
  
  // Use the fadeOut() method to hide the element with the class "lesson-item"
  $('.lesson-item').fadeOut();
  
});