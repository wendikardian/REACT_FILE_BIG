$(function() {
  // Use the hide method to hide <h1> elements
  $('h1').hide();
  
});

