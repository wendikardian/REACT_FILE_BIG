$(function() {
  // Add click() method for #change-css
  $('#change-css').click(function(){
    $('#text').css('color', 'red').css('font-size', '50px');
  })
    
});