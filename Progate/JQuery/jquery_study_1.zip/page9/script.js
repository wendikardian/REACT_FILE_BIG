$(function() {
  // Add a click() method for .list-item
  $('.list-item').click(function() {
    $(this).css('color', 'red');
  })
  
});