const number1 = 103;
const number2 = 72;
const number3 = 189;

// Write a function called getMax to get the maximum value
const getMax = (a,b,c) => {
  let max = 0;
  if( a > b){
    if( a > c){
      max = a;
    }else{
      max = c;
    }
  }else{
    if(b > c){
      max = b
    }else{
      max = c;
    }
  }
  return max;
}

// Print "The maximum value is __"
const result = getMax(number1, number2, number3);
console.log(`The maximum value is ${result}`);
