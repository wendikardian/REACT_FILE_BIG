const greet = function() {
  console.log("Hello!");
  console.log("Let's study functions!");
};

// Call the function here
greet();
