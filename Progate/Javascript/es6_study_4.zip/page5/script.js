class Animal {
  constructor() {
    // Assign the string value 「Leo」 to the name property
    this.name = "Leo";
    this.age = 3;
    // Assign the value 「3」 to the age property
    
  }
}

const animal = new Animal();

// Output 「Name: ____」
console.log(`Name: ${animal.name}`);
console.log(`Age: ${animal.age}`);

// Output 「Age: __」

