// Define the Animal class
class Animal{
  
}
