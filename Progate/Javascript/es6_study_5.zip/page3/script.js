// Remove the code below
import dog from "./dogData";

// Remove the code above
// Import the constant dog
dog.info();