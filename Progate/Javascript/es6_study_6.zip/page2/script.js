const characters = ["Ken the Ninja", "Ben the Baby Ninja", "Master Wooly", "Birdie"];

// Print all elements in the characters array by using the forEach method
characters.forEach((character) => {
  console.log(character);
});