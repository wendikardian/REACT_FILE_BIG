const characters = ["Ken the Ninja", "Ben the Baby Ninja", "Master Wooly"];

console.log(characters);

// Add the string "Birdie" to the characters array with the push method
characters.push("Birdie");
console.log(characters);
// Print the characters array

