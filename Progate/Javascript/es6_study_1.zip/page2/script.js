// Output "Hello World" to the console
console.log("Hello World");

// Output "Ken the Ninja" to the console
console.log("Ken the Ninja");

// Comment out the line below
// console.log("This line should be a comment");
