const age = 17;

// When the condition is not met, output "I am under 18 years old"
if (age >= 18) {
  console.log("I am 18 or older");
} else{
  console.log("I am under 18 years old");
}

