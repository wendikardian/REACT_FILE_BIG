// Output the combination of "Master " and "Wooly"
console.log("Master" + "Wooly");

// Output the combination of "20" and "15" (as a single string)
console.log("20" + "15");

