import React from 'react';

class App extends React.Component {
  render() {
    return (
    	<div>
    	  <h1>Hello, Ken the Ninja!</h1>
    	  {/* Add a <button> tag with the text "Master Wooly" */}
    	  <button>Master Wooly</button>
    	  
    	  {/* Add a <button> tag with the text "Ken the Ninja" */}
    	  <button>Ken the Ninja</button>
    	  
    	</div>
    );
  }
}

export default App;
