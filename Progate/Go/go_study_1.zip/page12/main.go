package main

func main() {
    x := 123
    y := 5 * 6
    
    // When x is greater than or equal to 100, print "x is greater than or equal to 100"
    if x >= 100 {
        println("x is greater than or equal to 100")
    }
    
    
    
    // When y is less than 40, print "y is less than 40"
    if y< 40{
        println("y is less than 40")
    }
    
}
