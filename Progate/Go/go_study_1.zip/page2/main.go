package main

func main() {
	println("Hello, world")
}
func sub() {
	println("Hello, Go")
}
