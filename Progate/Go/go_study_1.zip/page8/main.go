package main

func main() {
    var message string = "Hello, world"

    // Update the message variable with "Hello, Go"
    message = "Hello, Go"
	
	println(message)
}
