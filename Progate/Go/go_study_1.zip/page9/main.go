package main

func main() {
    // Declare the message variable and assign "Hello, world" to it
    var message = "Hello, world"
    
    // Declare the number variable and assign 100 to it 
    var number = 100
    
    // Print the values of message and number
    println(message, number)
    
}
