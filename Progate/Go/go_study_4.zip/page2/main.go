package main

import "fmt"

func main() {
	name := "John"

	// Print the name variable memory address
	fmt.Println(&name)

}
