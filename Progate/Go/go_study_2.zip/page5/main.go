package main

import "fmt"

func main() {
    name1 := "Ken the Ninja"
    name2 := "Master Wooly"
    name3 := "Ben the Baby"
    
    // Print each string with line-break using \n
    fmt.Printf("Welcome, %s\n", name1)
    fmt.Printf("Welcome, %s\n", name2)
    fmt.Printf("Welcome, %s\n", name3)
}
