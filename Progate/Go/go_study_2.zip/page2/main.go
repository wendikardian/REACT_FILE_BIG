package main

// Import the fmt package
import "fmt"

func main() {
    // Rewrite the code below to use the fmt package to print "Hello, world"
    fmt.Println("Hello, world")
}
