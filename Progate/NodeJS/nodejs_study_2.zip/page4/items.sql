INSERT INTO items(id,name) VALUES (1,'potatoes');
INSERT INTO items(id,name) VALUES (2,'carrots');
INSERT INTO items(id,name) VALUES (3,'onions');