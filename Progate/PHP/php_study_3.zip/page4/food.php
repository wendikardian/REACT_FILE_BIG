<?php 
// Import the menu.php file
require_once('menu.php');

// Create a Food class that inherits from the Menu class
class Food extends Menu {
  
}


?>