<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    $x = 5;
    $y = 2;
    $a = 8;
    $b = 4;
    
  ?>

  <!-- Update and print the $x variable below -->
  <?php
    $x += 10;
    echo $x
    
  ?>

  <br>

  <!-- Update and print the $y variable below -->
  <?php
    
    $y *= 5;
    echo $y
  ?>

  <br>

  <!-- Update and print the $a variable below -->
  <?php
    $a ++;
    echo $a;
    
  ?>

  <br>
  
  <!-- Update and print the $b variable below -->
  <?php
    $b --;
    echo $b
    
  ?>

</body>
</html>
