<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    // Declare the $i variable
    $i = 2;
    
    // Write the while loop below
    while($i <= 100){
      echo $i. '<br>';
      $i += 2;
    }
    
  ?>

</body>
</html>

