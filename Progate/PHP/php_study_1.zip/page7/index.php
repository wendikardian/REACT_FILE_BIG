<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php
    // Declare the $age variable below
    $age = 18;
    if($age >= 30){
      echo 'You are 30 years old or more.';
    }else{
      echo ' You are under 30 years old.';
    }
    
    
  ?>

</body>
</html>
