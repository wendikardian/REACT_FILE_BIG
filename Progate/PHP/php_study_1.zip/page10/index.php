<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    // Create the array below
    $colors = array('Red', 'Blue', 'Yellow');
    echo $colors[0];
    $colors[] = 'White';
    echo $colors[3];
    
  ?>

</body>
</html>