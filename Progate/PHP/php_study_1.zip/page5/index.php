<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php
    $name = 'Ken the Ninja';
    // Print "Hello, ____" using the $name variable. 
    echo "Hello, {$name}";
    
  ?>

</body>
</html>
