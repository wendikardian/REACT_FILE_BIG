<?php
$name = 'Tom';
echo 'Value of $name: '.$name;
echo '<br>';
echo '-----';
echo '<br>';

// Write your code below
echo 'My name is '.$name;

// Another solution using variable interpolation
// echo "My name is {$name}";

?>