<?php
  echo 'Hello, PHP <br>';
  echo '10 + 7';
?>