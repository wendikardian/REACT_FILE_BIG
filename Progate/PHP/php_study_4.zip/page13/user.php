<?php
class User {
  // Declare the $id private property
  
  private $id;
  private $name;
  private $gender;
  private static $count = 0;
  
  // Declare the $count private class property with 0 as the initial value
  
  
  public function __construct($name, $gender) {
    self::$count ++;
    $this->name = $name;
    $this->gender = $gender;
    $this->id = self::$count;
    // Increment the $count class property by 1
    
    
    // Assign the value of the $count class property to the id property
    
    
  }
  
  // Define the getId method
  public function getId(){
    return $this->id;
  }
  
  public function getName() {
    return $this->name;
  }

  public function getGender() {
    return $this->gender;
  }
}

?>